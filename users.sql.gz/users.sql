-- Adminer 4.7.6 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

CREATE DATABASE `test` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `test`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(32) NOT NULL,
  `pass` varchar(32) NOT NULL,
  `token` varchar(32) NOT NULL,
  `fio` varchar(128) NOT NULL,
  `image` varchar(256) NOT NULL,
  `berthday` date NOT NULL,
  `number` tinyint(3) unsigned NOT NULL,
  `ts` int(10) unsigned NOT NULL,
  `comment` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE INDEX fio ON `users` (fio);

INSERT INTO `users` (`id`, `login`, `pass`, `token`, `fio`, `image`, `berthday`, `number`, `ts`, `comment`) VALUES
(1,	'6ede584fe4f8a4ef76149ac96ee5fa8d',	'3f8a39a110595d185cfefb680e47fb85',	'',	'Иванов Иван',	'/img/users/',	'2023-05-16',	0,	0,	'ivanov ivan -> 123456789'),
(2,	'a08d892303bcd49c46d8301ce77999d1',	'efe708f3fbd3b9749e38715579889451',	'',	'Петров Петр',	'/img/users/',	'2023-05-16',	0,	0,	'petrov petr -> 987654321'),
(3,	'72fa042bd488757bbe82e0c23f709570',	'473110be8c72564d1ee2eca6215ae855',	'',	'Сидоров Сидр',	'/img/users/',	'2023-05-16',	0,	0,	'sidorov sidr -> 147258369'),
(4,	'4e33e87f6e9701fd9aa5415b52c927fd',	'fb934f8a6dd27e133f80f093aeb2b0bb',	'',	'Пивчиков Пив',	'/img/users/',	'2023-05-16',	0,	0,	'pivchikov piv -> 741852963');

-- 2023-05-16 09:21:37
